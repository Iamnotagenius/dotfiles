vim.opt.mouse = 'a'
vim.g.neovide_cursor_vfx_mode = "torpedo"
vim.g.neovide_refresh_rate = 72
vim.g.neovide_cursor_vfx_opacity = 120.0
vim.g.neovide_cursor_vfx_particle_lifetime = 1.2
vim.g.neovide_cursor_vfx_particle_density = 20.0
vim.g.neovide_cursor_vfx_particle_lifetime = 2.3
